
# قالب موقع ألعاب عشوائية (Static)

- افتح `index.html` مباشرة أو ارفع المجلد كاملًا إلى GitHub Pages / Netlify / Vercel.
- لإضافة ألعاب جديدة:
  1) أنشئ ملف HTML داخل مجلد `games/` (انسخ لعبة موجودة وعدّل).
  2) ضع صورة مصغّرة في `assets/`.
  3) أضف عنصرًا جديدًا داخل `games.json` يحتوي على: id, title, desc, url, tags, thumb.
- زر "🎲 جرّب حظك" ينقلك إلى لعبة عشوائية.
- البحث + الفلاتر تعمل بالكامل في المتصفح (بدون باك-إند).
- يمكنك تحويله لتطبيق PWA بإضافة ربط `manifest.json` و `sw.js` في `index.html` (إضافة `<link rel="manifest" ...>` و `<script>navigator.serviceWorker.register('sw.js')</script>`).
