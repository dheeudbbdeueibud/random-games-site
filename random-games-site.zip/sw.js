self.addEventListener('install', e=>{
  e.waitUntil(caches.open('rg-v1').then(c=>c.addAll(['./','index.html','styles.css','script.js','games.json',
    'games/snake.html','games/tictactoe.html','games/2048.html',
    'assets/snake.png','assets/ttt.png','assets/2048.png'])));
});
self.addEventListener('fetch', e=>{
  e.respondWith(caches.match(e.request).then(r=> r || fetch(e.request)));
});
