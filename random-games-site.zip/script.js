const grid = document.getElementById('grid');
const search = document.getElementById('search');
const tagsSelect = document.getElementById('tags');
const luckyBtn = document.getElementById('lucky');
const countEl = document.getElementById('count');

let games=[], filtered=[], tags=[];

async function load(){
  const res = await fetch('games.json');
  games = await res.json();
  tags = Array.from(new Set(games.flatMap(g=>g.tags))).sort();
  tagsSelect.innerHTML = `<option value="">كل التصنيفات</option>` + tags.map(t=>`<option>${t}</option>`).join('');
  apply();
}
function apply(){
  const q = (search.value||'').trim().toLowerCase();
  const tag = tagsSelect.value;
  filtered = games.filter(g=>{
    const okQ = !q || g.title.toLowerCase().includes(q) || g.desc.toLowerCase().includes(q);
    const okT = !tag || g.tags.includes(tag);
    return okQ && okT;
  });
  // randomize order each time to feel "عشوائي"
  filtered = filtered.sort(()=>Math.random()-.5);
  render(filtered);
}
function render(list){
  countEl.textContent = list.length;
  grid.innerHTML = list.map(g=>`
    <article class="card">
      <img src="${g.thumb}" alt="${g.title}">
      <div class="body">
        <h3>${g.title}</h3>
        <p class="muted">${g.desc}</p>
        <div class="badges">${g.tags.map(t=>`<span class="badge">${t}</span>`).join('')}</div>
        <div class="controls">
          <a href="${g.url}"><button>تشغيل اللعبة</button></a>
          <button onclick="share('${g.title}','${location.origin+location.pathname.replace(/\/[^/]*$/,'/')+g.url}')">مشاركة</button>
        </div>
      </div>
    </article>
  `).join('');
}
function lucky(){
  if(!games.length) return;
  const g = games[Math.floor(Math.random()*games.length)];
  location.href = g.url;
}
function share(title, url){
  if(navigator.share){ navigator.share({title, url}); }
  else { navigator.clipboard.writeText(url); alert('تم نسخ الرابط: ' + url); }
}
search.addEventListener('input', apply);
tagsSelect.addEventListener('change', apply);
luckyBtn.addEventListener('click', lucky);
load();
